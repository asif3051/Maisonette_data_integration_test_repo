# import sys
# import json
# import time
# import requests
# from pyspark.sql import SparkSession
# from pyspark.sql.functions import explode_outer
# from pyspark.sql.types import StructType
# from pyspark.sql.types import ArrayType
# from pyspark.sql.types import StringType
# from pyspark.sql import functions as F 
# from awsglue.context import GlueContext
# from pyspark.sql.functions import col
# from pyspark.sql.functions import explode_outer
# from pyspark.sql.types import *
# from pyspark import SparkContext
# from pyspark.sql.functions import from_json
# from pyspark.sql.functions import countDistinct
from awsglue.utils import getResolvedOptions
from Maisonette.ParameterRead import get_parameter_values



def rdsConnectionInfo():
        
    retrieved_values = get_parameter_values()

    return retrieved_values


def load_data_rds(df):
    
    retrieved_values = rdsConnectionInfo()

    df.write \
            .format("jdbc")\
            .mode("append")\
            .option("url", "jdbc:postgresql://{rds_host}:{rds_port}/{rds_dbname}".format(rds_host=retrieved_values["DB_HOST"], rds_port=retrieved_values["DB_PORT"], rds_dbname=retrieved_values["DB_NAME"]))\
            .option("dbtable", "airbytelanding.salsify_imports_flattened_processed_2") \
            .option("user", retrieved_values["DB_USERNAME"]) \
            .option("password", retrieved_values["DB_PASSWORD"]) \
            .option("driver", "org.postgresql.Driver") \
            .option("mode", "append") \
            .save()
    
