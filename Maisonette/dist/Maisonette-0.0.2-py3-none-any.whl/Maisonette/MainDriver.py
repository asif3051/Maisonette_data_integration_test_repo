# import sys
# import json
# import time
from awsglue.utils import getResolvedOptions
from pyspark.sql import SparkSession
# from pyspark.sql.functions import explode_outer
# from pyspark.sql.types import StructType
# from pyspark.sql.types import ArrayType
# from pyspark.sql.types import StringType
# from pyspark.sql import functions as F 
# import requests
# from awsglue.context import GlueContext
# from pyspark.sql.functions import col
# from pyspark.sql.functions import explode_outer
from pyspark.sql.types import *
# from pyspark import SparkContext
# from pyspark.sql.functions import from_json
# from pyspark.sql.functions import countDistinct
from Maisonette.ParameterRead import get_parameter_values
from Maisonette.ReadData import extract
from Maisonette.Flatten import flatten
from Maisonette.ProcessName import process_name
from Maisonette.SaveData import load_data_rds



def main():
    spark = SparkSession \
                    .builder \
                    .appName("Maisonette") \
                    .getOrCreate()
    
    #extract
    rawdf = extract(spark)
    # rawdf_count = rawdf.count()


    #tranform
    retrundf = flatten(spark,rawdf)
    # retrundf_count = retrundf.count()
    # rawdf_schema = str(rawdf.schema)
    # retrundf_schema = str(retrundf.schema)
    
    
    # df_count = spark.createDataFrame(
    # [
    #     (1, rawdf_count,rawdf_schema),  # create your data here, be consistent in the types.
    #     (2, retrundf_count,retrundf_schema)
    # ],
    # ["id", "row_count","schema_columns"]  # add your column names here
    # )
    # df_count.write.csv("s3://maisonette-airbyte-integration-landing-dev/row_details/", mode="overwrite", header = True)
    
    #write to s3
    # count_df_rows_unflattened(rawdf)
    # count_df_rows_flattened(retrundf)
    df3 = process_name(retrundf)
    #load data to s3
    # data_s3(df3)
    
    load_data_rds(df3)
    #load
    # load(retrundf)
    
    spark.stop()
   

    