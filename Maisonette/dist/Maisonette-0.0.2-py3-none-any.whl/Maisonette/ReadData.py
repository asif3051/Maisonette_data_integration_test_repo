# import sys
# import json
# import time
# from awsglue.utils import getResolvedOptions
# from pyspark.sql import SparkSession
# from pyspark.sql.functions import explode_outer
# from pyspark.sql.types import StructType
# from pyspark.sql.types import ArrayType
# from pyspark.sql.types import StringType
# from pyspark.sql import functions as F 
# import requests
# from awsglue.context import GlueContext
# from pyspark.sql.functions import col
# from pyspark.sql.functions import explode_outer
# from pyspark.sql.types import *
# from pyspark import SparkContext
# from pyspark.sql.functions import from_json
# from pyspark.sql.functions import countDistinct
from Maisonette.ParameterRead import get_parameter_values
from awsglue.utils import getResolvedOptions


def rdsConnectionInfo():
        
    retrieved_values = get_parameter_values()

    return retrieved_values



#extract function
def extract(spark):

    
    retrieved_values = rdsConnectionInfo()

    rawdf = spark.read.format("jdbc")\
                  .option("url", "jdbc:postgresql://{rds_host}:{rds_port}/{rds_dbname}".format(rds_host=retrieved_values["DB_HOST"], rds_port=retrieved_values["DB_PORT"], rds_dbname=retrieved_values["DB_NAME"]))\
                  .option("dbtable", "airbytelanding_raw._airbyte_raw_salsify_imports") \
                  .option("user", retrieved_values["DB_USERNAME"]) \
                  .option("password", retrieved_values["DB_PASSWORD"]) \
                  .option("driver","org.postgresql.Driver")\
                  .load()

    return rawdf
